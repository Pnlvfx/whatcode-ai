## [2.41.0](///compare/@coraline/client@2.40.0...@coraline/client@2.41.0) "@coraline/client" (2026-06-12)

### Features

* use new goatjs pkgs 336aa56

## [2.40.0](///compare/@coraline/client@2.39.0...@coraline/client@2.40.0) "@coraline/client" (2026-06-05)

### Bug Fixes

* deps mess 531a3b9
* deps mess 57681e1

## [2.39.0](///compare/@coraline/client@2.38.0...@coraline/client@2.39.0) "@coraline/client" (2026-06-04)

### Features

* new logger main version, a lot of breaking changes (everything) f88cad5
* switch to zod core on server, zod mini on both db and server logger f553674

## [2.38.0](///compare/@coraline/client@2.37.0...@coraline/client@2.38.0) "@coraline/client" (2026-05-31)

### Bug Fixes

* doctor cure 162edf3

## 2.37.0 "@coraline/client" (2026-05-29)

### Features

* add signal on client 27a0d0c
* fuck you dude, i did it ecdfe26
* improve server 8d17532
* improve server logger 32865bc
* **server:** nested router 4b4387b

### Bug Fixes

* deps 9f451d1
* do not include undefined on the query cd180dd
* publish 35993ea
* return 204 for emptyResponse dc4e765

### Reverts

* types bc82817

## 2.36.0 "@coraline/client" (2026-05-29)

### Features

* add signal on client 27a0d0c
* fuck you dude, i did it ecdfe26
* improve server 8d17532
* improve server logger 32865bc
* **server:** nested router 4b4387b

### Bug Fixes

* deps 9f451d1
* do not include undefined on the query cd180dd
* return 204 for emptyResponse dc4e765

### Reverts

* types bc82817

## 2.35.0 "@coraline/client" (2026-05-29)

### Features

* add signal on client 27a0d0c
* fuck you dude, i did it ecdfe26
* improve server 8d17532
* improve server logger 32865bc
* **server:** nested router 4b4387b

### Bug Fixes

* do not include undefined on the query cd180dd
* return 204 for emptyResponse dc4e765

### Reverts

* types bc82817

## [2.34.0](///compare/@coraline/client@2.33.0...@coraline/client@2.34.0) "@coraline/client" (2026-05-28)

### Reverts

- types bc82817
