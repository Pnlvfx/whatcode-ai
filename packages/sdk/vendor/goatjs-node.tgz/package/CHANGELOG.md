## [2.26.0](///compare/@goatjs/node@2.25.0...@goatjs/node@2.26.0) "@goatjs/node" (2026-06-12)

### Features

* migrate prettier to a separate package eb611e4

## [2.25.0](///compare/@goatjs/node@2.24.0...@goatjs/node@2.25.0) "@goatjs/node" (2026-06-10)

### Bug Fixes

* **store:** move store on his own c1e2758

## [2.24.0](///compare/@goatjs/node@2.23.0...@goatjs/node@2.24.0) "@goatjs/node" (2026-06-06)

### Features

* **dbz:** add --release on publish to add the release on gh ea99fb7

## [2.23.0](///compare/@goatjs/node@2.22.0...@goatjs/node@2.23.0) "@goatjs/node" (2026-06-05)

### Bug Fixes

* des e638879

## [2.22.0](///compare/@goatjs/node@2.21.0...@goatjs/node@2.22.0) "@goatjs/node" (2026-06-04)

### Features

* migrate to zod mini 8922bfd

## [2.21.0](///compare/@goatjs/node@2.20.0...@goatjs/node@2.21.0) "@goatjs/node" (2026-05-30)

### Bug Fixes

* **doctor:** compiler 66a682f

## [2.20.0](///compare/@goatjs/node@2.19.0...@goatjs/node@2.20.0) "@goatjs/node" (2026-05-29)

### Features

* create doctor 60eb0d2

## [2.19.0](///compare/@goatjs/node@2.18.0...@goatjs/node@2.19.0) "@goatjs/node" (2026-05-29)

### Bug Fixes

* dbz too long commit 7c92414

