# @coraline/server

Type-safe Express wrapper with automatic API spec generation.

## Installation

```bash
npm install @coraline/server zod
```

## Quick Start

### 1. Define endpoints

```ts
import { createRouteEndpoint, createRouter, jsonResponse, emptyResponse } from '@coraline/server';
import * as z from 'zod/v4/mini';

const getUsers = createRouteEndpoint({
  method: 'get',
  path: '/',
  handler: () => {
    return jsonResponse([{ id: '1', name: 'Alice' }]);
  },
});

const getUserById = createRouteEndpoint({
  method: 'get',
  path: '/:id',
  validate: {
    params: z.strictObject({ id: z.string() }),
  },
  handler: ({ params }) => {
    return jsonResponse({ id: params.id, name: 'Alice' });
  },
});

const createUser = createRouteEndpoint({
  method: 'post',
  path: '/',
  validate: {
    body: z.strictObject({ name: z.string(), email: z.email() }),
  },
  handler: ({ body }) => {
    return jsonResponse({ id: '2', name: body.name, email: body.email }, { status: 201 });
  },
});

const deleteUser = createRouteEndpoint({
  method: 'delete',
  path: '/:id',
  validate: {
    params: z.strictObject({ id: z.string() }),
  },
  handler: () => emptyResponse(204),
});

export const usersRouter = createRouter({ getUsers, getUserById, createUser, deleteUser });
```

### 2. Create the app

```ts
import { createApp } from '@coraline/server';
import { usersRouter } from './routes/users.ts';

const app = createApp({
  port: 4000,
  json: { limit: '10mb' },
  urlencoded: { extended: true },
  routes: {
    '/users': usersRouter,
  },
});

// Generate the API spec for connected clients (run once on startup)
await app.generateApiSpec([{ cwd: '/path/to/client', fullPath: '/path/to/client/src/lib' }]);

type ApiSpec = typeof app.__spec;
export type { ApiSpec };
```

`generateApiSpec` writes a `__spec/__api-spec.ts` file into each client path. It is hash-based and only rewrites when the spec changes.

## API

### `createRouteEndpoint(def)`

Defines a single route. All fields except `method`, `path`, and `handler` are optional.

| Field             | Type                                   | Description                                   |
| ----------------- | -------------------------------------- | --------------------------------------------- |
| `method`          | `'get' \| 'post' \| 'put' \| 'delete'` | HTTP method                                   |
| `path`            | `string`                               | Express path (e.g. `'/'`, `'/:id'`)           |
| `validate.params` | `z.ZodType`                            | Validates `req.params`                        |
| `validate.query`  | `z.ZodType`                            | Validates `req.query`                         |
| `validate.body`   | `z.ZodType`                            | Validates `req.body`                          |
| `middleware`      | `Middleware[]`                         | List of middlewares to run before the handler |
| `handler`         | `(ctx) => ServerResponse`              | Route handler                                 |

Validation errors automatically return `400`.

### `createRouter(endpoints, options?)`

Groups endpoints into a router. The object keys become the endpoint names used in the API spec.

```ts
export const usersRouter = createRouter({ getUsers, getUserById, createUser, deleteUser });
```

### `createApp(config)`

| Field           | Type                                          | Description                                                                            |
| --------------- | --------------------------------------------- | -------------------------------------------------------------------------------------- |
| `port`          | `number`                                      | Port to listen on                                                                      |
| `routes`        | `Record<string, RouteEndpoint \| GoatRouter>` | Route map. Key is the URL prefix for routers, or the spec key for standalone endpoints |
| `middlewares`   | `RequestHandler[]`                            | Express middlewares applied globally                                                   |
| `json`          | `OptionsJson`                                 | `express.json()` options                                                               |
| `urlencoded`    | `OptionsUrlencoded`                           | `express.urlencoded()` options                                                         |
| `trustProxy`    | `boolean`                                     | Sets `trust proxy`                                                                     |
| `expressRoutes` | `(express) => void`                           | Escape hatch for raw Express routes                                                    |

### Response helpers

```ts
import { jsonResponse, plainResponse, emptyResponse, redirectResponse, streamResponse } from '@coraline/server';

// JSON — wraps data in { data: ... }
return jsonResponse({ id: '1', name: 'Alice' });
return jsonResponse(result, { status: 201 });

// Plain text
return plainResponse('hello');

// Empty (e.g. 204 No Content)
return emptyResponse(204);

// Redirect
return redirectResponse(302, 'https://example.com');

// Stream
return streamResponse(readableStream);
```

All response helpers accept optional `cookies`, `clearCookies`, `headers`, and `afterSend`.

### Error helpers

```ts
import { serverError, notFound, forbiden, unhautorized } from '@coraline/server';

throw notFound('User'); // 404: User not found!
throw forbiden(); // 403: Forbidden!
throw unhautorized(); // 401: Unauthorized!
throw serverError('Oops', { status: 422 });
```

### Middleware

Middleware runs before the handler and merges its return value into `ctx`.

```ts
import { createMiddleware } from '@coraline/server';

const authMiddleware = createMiddleware(async ({ headers }) => {
  const token = headers.authorization;
  if (!token) throw unhautorized();
  const user = await verifyToken(token);
  return { user }; // merged into ctx
});

const getProfile = createRouteEndpoint({
  method: 'get',
  path: '/profile',
  middleware: [authMiddleware] as const,
  handler: ({ user }) => jsonResponse(user), // ctx.user is typed
});
```

### Built-in routes

```ts
import { createLogHandler } from '@coraline/server/routes/telegram';

// POST /logs — sends a message to a Telegram group
const sendLog = createLogHandler(); // default path: /logs
const sendLog = createLogHandler('/custom-path');
```
