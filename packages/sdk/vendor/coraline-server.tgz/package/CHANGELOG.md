## [4.98.0](///compare/@coraline/server@4.97.0...@coraline/server@4.98.0) "@coraline/server" (2026-06-12)

### Features

* **server:** some app startup tweaks (breaking) f76a9b5

## [4.97.0](///compare/@coraline/server@4.96.0...@coraline/server@4.97.0) "@coraline/server" (2026-06-12)

### Features

* use new goatjs pkgs 336aa56

## [4.96.0](///compare/@coraline/server@4.95.0...@coraline/server@4.96.0) "@coraline/server" (2026-06-05)

### Bug Fixes

* **server:** skip static on collect router b3e3059

## [4.95.0](///compare/@coraline/server@4.94.0...@coraline/server@4.95.0) "@coraline/server" (2026-06-05)

### Bug Fixes

* **breaking:** change static to key directory 7b5a539
* deps mess 57681e1

## [4.94.0](///compare/@coraline/server@4.93.0...@coraline/server@4.94.0) "@coraline/server" (2026-06-04)

### Features

* switch to zod core on server, zod mini on both db and server logger f553674

## [4.93.0](///compare/@coraline/server@4.92.0...@coraline/server@4.93.0) "@coraline/server" (2026-06-04)

### Features

* new logger main version, a lot of breaking changes (everything) f88cad5
* return a boolean on generateApiSpec d3545cb

## [4.92.0](///compare/@coraline/server@4.91.0...@coraline/server@4.92.0) "@coraline/server" (2026-05-31)

### Bug Fixes

* doctor cure 162edf3

## [4.91.0](///compare/@coraline/server@4.90.0...@coraline/server@4.91.0) "@coraline/server" (2026-05-29)

### Bug Fixes

* **server:** flat exports 440e092

## 4.90.0 "@coraline/server" (2026-05-29)

### Features

* add signal on client 27a0d0c
* fuck you dude, i did it ecdfe26
* improve server 8d17532
* improve server logger 32865bc
* new logger features 1d0140b
* **server:** nested router 4b4387b

### Bug Fixes

* **all:** types 9290142
* deps 9f451d1
* publish 35993ea
* return 204 for emptyResponse dc4e765
* **server:** improve perfs 70e6f0c

## 4.89.0 "@coraline/server" (2026-05-29)

### Features

* add signal on client 27a0d0c
* fuck you dude, i did it ecdfe26
* improve server 8d17532
* improve server logger 32865bc
* new logger features 1d0140b
* **server:** nested router 4b4387b

### Bug Fixes

* **all:** types 9290142
* deps 9f451d1
* return 204 for emptyResponse dc4e765
* **server:** improve perfs 70e6f0c

## 4.88.0 "@coraline/server" (2026-05-29)

### Features

* add signal on client 27a0d0c
* fuck you dude, i did it ecdfe26
* improve server 8d17532
* improve server logger 32865bc
* new logger features 1d0140b
* **server:** nested router 4b4387b

### Bug Fixes

* **all:** types 9290142
* return 204 for emptyResponse dc4e765
* **server:** improve perfs 70e6f0c

## [4.87.0](///compare/@coraline/server@4.86.0...@coraline/server@4.87.0) "@coraline/server" (2026-05-28)

### Bug Fixes

- **all:** types 9290142

## [4.86.0](///compare/@coraline/server@4.85.0...@coraline/server@4.86.0) "@coraline/server" (2026-05-28)

### Bug Fixes

- **server:** improve perfs 70e6f0c
