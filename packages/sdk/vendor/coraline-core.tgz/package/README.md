# @coraline/client

Type-safe API client for `@coraline/server`. Works in any environment (Node.js, browser, React Native).

For Next.js, use `@coraline/nextjs` instead — it handles server/client header forwarding automatically.

## Installation

```bash
npm install @coraline/client
```

## Setup

### 1. Generate the spec

The server must call `generateApiSpec` on startup pointing at your client project. This writes `__spec/__api-spec.ts` into the target directory.

See `@coraline/server` docs for how to configure this.

### 2. Create the client

```ts
// src/lib/api.ts
import type { ApiSpec } from '../my-server/dist/server'; // server dist types
import { createApiClient } from '@coraline/client';
import { apiSpec } from './__spec/__api-spec.js';

export const api = createApiClient<ApiSpec>(apiSpec, {
  serverUrl: 'https://api.example.com',
});
```

### 3. Make requests

```ts
// GET /users
const users = await api.request('getUsers', {});

// GET /users/:id
const user = await api.request('getUserById', { params: { id: '1' } });

// GET /search?q=alice
const results = await api.request('searchUsers', { query: { q: 'alice' } });

// POST /users
const created = await api.request('createUser', { body: { name: 'Alice', email: 'alice@example.com' } });

// DELETE /users/:id (emptyResponse — returns void)
await api.request('deleteUser', { params: { id: '1' } });
```

All parameters (`params`, `query`, `body`) are fully typed from the server's Zod schemas. The return type is inferred from the server handler's return value.

## Options

```ts
createApiClient<TSpec>(apiSpec, {
  serverUrl: 'https://api.example.com', // base URL
  headers: new Headers({ authorization: 'Bearer token' }), // optional default headers
});
```

## Error handling

When the server returns a non-ok response with a JSON body, the client throws a typed fetch error with `message` and `status`:

```ts
try {
  const user = await api.request('getUser', { params: { id: '999' } });
} catch (err) {
  // err.status — HTTP status code
  // err.message — error message from server
}
```

## TypeScript

The `ParsedItem<T>` utility type transforms server-side types to their serialized equivalents (e.g. `Date` → `string`, `ObjectId` → `string`):

```ts
import type { ParsedItem } from '@coraline/client';

type User = { id: string; createdAt: Date };
type SerializedUser = ParsedItem<User>; // { id: string; createdAt: string }
```
