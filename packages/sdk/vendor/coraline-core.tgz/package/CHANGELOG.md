## [2.39.0](///compare/@coraline/core@2.38.0...@coraline/core@2.39.0) "@coraline/core" (2026-06-04)

### Features

* new logger main version, a lot of breaking changes (everything) f88cad5
* switch to zod core on server, zod mini on both db and server logger f553674

## [2.38.0](///compare/@coraline/core@2.37.0...@coraline/core@2.38.0) "@coraline/core" (2026-05-31)

### Bug Fixes

* doctor cure 162edf3

## 2.37.0 "@coraline/core" (2026-05-29)

### Features

* fuck you dude, i did it ecdfe26

### Bug Fixes

* deps 9f451d1
* publish 35993ea

## 2.36.0 "@coraline/core" (2026-05-29)

### Features

* fuck you dude, i did it ecdfe26

### Bug Fixes

* deps 9f451d1

## 2.35.0 "@coraline/core" (2026-05-29)

### Features

* fuck you dude, i did it ecdfe26

