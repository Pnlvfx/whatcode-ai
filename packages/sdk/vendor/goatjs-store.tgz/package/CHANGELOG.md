## 2.17.0 "@goatjs/store" (2026-06-10)

### Bug Fixes

* **store:** move store on his own c1e2758

