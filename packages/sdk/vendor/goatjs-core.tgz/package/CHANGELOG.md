## [2.18.0](///compare/@goatjs/core@2.17.0...@goatjs/core@2.18.0) "@goatjs/core" (2026-06-11)

## [2.17.0](///compare/@goatjs/core@2.16.0...@goatjs/core@2.17.0) "@goatjs/core" (2026-06-10)

### Bug Fixes

* **store:** move store on his own c1e2758

## [2.16.0](///compare/@goatjs/core@2.15.0...@goatjs/core@2.16.0) "@goatjs/core" (2026-06-05)

### Bug Fixes

* des e638879
* remove zod from core 8399c2b

## [2.15.0](///compare/@goatjs/core@2.14.0...@goatjs/core@2.15.0) "@goatjs/core" (2026-06-04)

### Bug Fixes

* breaking: debounce and throttle return change 90151b8

## [2.14.0](///compare/@goatjs/core@2.13.0...@goatjs/core@2.14.0) "@goatjs/core" (2026-06-04)

### Features

* migrate to zod mini 8922bfd

### Bug Fixes

* **doctor:** compiler 66a682f

## [2.13.0](///compare/@goatjs/core@2.12.0...@goatjs/core@2.13.0) "@goatjs/core" (2026-05-29)

### Features

* create doctor 60eb0d2

## [2.12.0](///compare/@goatjs/core@2.11.0...@goatjs/core@2.12.0) "@goatjs/core" (2026-05-29)

### Bug Fixes

* dbz too long commit 7c92414

